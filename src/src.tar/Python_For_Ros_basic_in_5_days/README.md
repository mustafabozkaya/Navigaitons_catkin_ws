# Python_For_Ros_basic_in_5_days
basics python ros example created 
